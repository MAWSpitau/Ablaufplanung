# Ablaufplanung

Diese Vorlage ermöglicht es, einen Ablauf eines Seminars, eines Unterrichts oder einer Schulung zu planen.

Die Vorlage folgt der didaktischen Route.

![Screenshot der noch nicth ausgefüllten Tabelle](screenshot01.jpg)
